const { startConnection } = require("../../helpers/databaseConnection");
let connection = startConnection();
// let poolconnection=PoolConnection();

class CmsContent {

  static addMaster(tableName, value) {
    return new Promise((resolve, reject) => {
      connection.query(
        `insert into ${tableName} set ?`,
        [value],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }

  static updateMaster(tableName, id, value, column = "id") {
    return new Promise((resolve, reject) => {
      connection.query(
        `update ${tableName} set ? where ${column} = ?`,
        [value, id],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }



  static deleteMasterfromTable(tableName, condition) {
    // console.log(`DELETE FROM ${tableName} where ${condition}`)
    return new Promise((resolve, reject) => {
      connection.query(
        `DELETE FROM ${tableName} where  ${condition}`,
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }
 

 
 
  static getFreedom(selection, tableName, condition, groupby, orderby) {
    return new Promise((resolve, reject) => {
      connection.query(
        `select ${selection} from ${tableName} where ${condition} group by ${groupby} order by ${orderby}`,
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }
 
}

module.exports = CmsContent;
